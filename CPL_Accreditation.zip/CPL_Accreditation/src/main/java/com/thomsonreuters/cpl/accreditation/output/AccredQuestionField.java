package com.thomsonreuters.cpl.accreditation.output;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredQuestionField {

	public enum QuestionFieldType {
		TEXT_FIELD, RADIO, DATE
	}

	private QuestionFieldType questionFieldType;

	private String key;

	private String question;

	private List<AccredRadioQuestionFieldOption> options;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public QuestionFieldType getQuestionFieldType() {
		return questionFieldType;
	}

	public void setQuestionFieldType(QuestionFieldType questionFieldType) {
		this.questionFieldType = questionFieldType;
	}

	public List<AccredRadioQuestionFieldOption> getOptions() {
		return options;
	}

	public void setOptions(List<AccredRadioQuestionFieldOption> options) {
		this.options = options;
	}

}
