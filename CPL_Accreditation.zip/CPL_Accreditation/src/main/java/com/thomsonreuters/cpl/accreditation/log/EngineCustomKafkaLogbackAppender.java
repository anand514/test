package com.thomsonreuters.cpl.accreditation.log;

import org.apache.kafka.common.config.ConfigException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thomsonreuters.enterpriselogging.appender.logback.EnterpriseKafkaLogbackAppender;

import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * this is a engine custom kafka logback appender, useful to prevent the
 * application from stopping when it is unable to connect to kafka broker, in
 * this class we are overriding the default behavior of
 * EnterpriseKafkaLogbackAppender
 * 
 * @author mohan reddy
 *
 */
public class EngineCustomKafkaLogbackAppender extends EnterpriseKafkaLogbackAppender {

	private static final Logger LOG = LoggerFactory.getLogger(EngineCustomKafkaLogbackAppender.class);

	private boolean isConnectedToElkServer = true;

	public EngineCustomKafkaLogbackAppender() {
	}

	@Override
	public void start() {
		try {
			super.start();
		} catch (ConfigException e) {
			if (!e.getMessage().contains("bootstrap.servers")) {
				throw e;
			}
			isConnectedToElkServer = false;
			// if application unable to connect to the kakfa broker, don't stop
			// the application, continue running application
			LOG.error("Application unable to connect to the mentioned kafka url", e);
		}
	}

	@Override
	protected void append(ILoggingEvent arg0) {
		if (isConnectedToElkServer) {
			super.append(arg0);
		}

	}
}
