package com.thomsonreuters.cpl.accreditation.input;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class FieldOfStudyInput {
	
	public static final String FIELD_OF_STUDY_TAG="<FieldOfStudyInput>";

	@NotNull
	@Valid
	private AccredIndustryFieldOfStudy input;

	public AccredIndustryFieldOfStudy getInput() {
		return input;
	}

	public void setInput(AccredIndustryFieldOfStudy input) {
		this.input = input;
	}

}
