package com.thomsonreuters.cpl.accreditation.input;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class ContentDistributorInput {

	@NotNull
	@NotEmpty
	private List<Integer> industries;

	public List<Integer> getIndustries() {
		return industries;
	}

	public void setIndustries(List<Integer> industries) {
		this.industries = industries;
	}

}
