package com.thomsonreuters.cpl.accreditation.log;

public interface LoggingConstants {
	
	String EVENT_TYPE = "eventType";

	String APPLICATION = "application";

	String TRACKING_ID = "trackingId";

	String CLASS_NAME = "className";

	String METHOD_NAME = "methodName";

	String TIME_STAMP = "timeStamp";

	String EXECUTION_TIME = "executionTime";

	String SEVERITY = "severity";

	String LOG_LEVEL = "logLevel";

	String LOGGING_MESSAGE_OBJ = "loggingMessageObj";

	String LOGGING_MESSAGE = "loggingMessage";

	String INPUT_FOR_METHOD = "inputForMethod";

	String OUTPUT_FROM_METHOD = "outputFromMethod";

	String XML_RULES_ENGINE_COMPLIANCE_REQUESTS = "xmlrulesenginecompliancerequests";

	String LEARN_LIVE_LOG = "learnLiveLog";

	String STACK_TRACE = "stackTrace";
	
	String REGULATOR_ID="regulatorId";

	String COMPLIANCE_QUEUE_ID="complianceQueueId";

	String RULE_ID = "ruleId";

	String LOGIC = "logic";

	String INSTRUCTION = "instruction";

	String ASSIGNMENT = "assignment";

	String INSTRUCTION_EVALUATION_RESULT = "instructionEvaluationResult";

	String OUTPUT_ACTION_STATEMENT = "outputActionStatement";

	String MESSAGE_ACTION_STATEMENT_CONTENT = "messageActionStatementContent";

	String MISSING_QUESTION = "missingQuestion";

	String UPDATE_TYPE = "updateType";

	String DATE_VALUE = "dateValue";

	String ORG_USER_NAME = "orgUserName";

	String IP_ADDRESS = "ipAddress";

	String HOST_NAME = "hostName";
}
