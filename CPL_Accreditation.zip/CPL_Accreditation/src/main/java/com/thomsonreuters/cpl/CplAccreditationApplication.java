package com.thomsonreuters.cpl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CplAccreditationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CplAccreditationApplication.class, args);
	}
}
