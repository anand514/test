package com.thomsonreuters.cpl.accreditation.input;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class CustomDateStringSerializer extends JsonSerializer<String> {

	@Override
	public void serialize(String value, JsonGenerator gen, SerializerProvider serializers)
			throws IOException, JsonProcessingException {
		// use this serializer only for the date string values
		String replacedString=value;
		if (value.contains("-")) {
			replacedString = replacedString.replaceAll("-", "_");
		}
		gen.writeString(replacedString);
	}

}
