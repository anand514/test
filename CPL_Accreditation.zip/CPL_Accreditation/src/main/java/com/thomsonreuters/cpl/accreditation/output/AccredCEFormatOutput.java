package com.thomsonreuters.cpl.accreditation.output;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredCEFormatOutput {

	private List<AccredCEFormat> formats;

	public AccredCEFormatOutput(List<AccredCEFormat> formats) {
		this.formats = formats;
	}

	public AccredCEFormatOutput() {

	}

	public List<AccredCEFormat> getFormats() {
		return formats;
	}

	public void setFormats(List<AccredCEFormat> formats) {
		this.formats = formats;
	}
}
