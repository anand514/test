package com.thomsonreuters.cpl.accreditation.output;

import java.util.List;

public class ContentDistributorOutput {

	private List<AccredDistributorDefinition> distributorDefinitions;

	public List<AccredDistributorDefinition> getDistributorDefinitions() {
		return distributorDefinitions;
	}

	public void setDistributorDefinitions(List<AccredDistributorDefinition> distributorDefinitions) {
		this.distributorDefinitions = distributorDefinitions;
	}

}
