package com.thomsonreuters.cpl.accreditation.config;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.UriTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.thomsonreuters.cpl.accreditation.common.OrganizationAccess;
import com.thomsonreuters.cpl.accreditation.common.OrganizationApiAccess;
import com.thomsonreuters.cpl.accreditation.exceptions.AccreditationAPIAccessException;
import com.thomsonreuters.cpl.accreditation.exceptions.AccreditationAPICallFailedException;
import com.thomsonreuters.cpl.accreditation.exceptions.AccreditationResourceAccessException;
import com.thomsonreuters.cpl.accreditation.exceptions.ExceptionResponse;
import com.thomsonreuters.cpl.accreditation.exceptions.ExceptionResponse.ErrorCode;
import com.thomsonreuters.cpl.accreditation.log.LogJSONBuilder;
import com.thomsonreuters.cpl.accreditation.utility.RestClientUtility;

@Component
public class AuthenticationFilter extends OncePerRequestFilter {

	private RestClientUtility restClient;

	private LogJSONBuilder builder;

	private static final Logger LOG = LoggerFactory.getLogger(AuthenticationFilter.class);

	@Autowired
	public AuthenticationFilter(@Value("${eventType}") String eventType, @Value("${application}") String application,
			@Value("${accreditation.data.service.url}") String accredDataServiceUrl,
			@Value("${xmlrulesengine.service.url}") String engineServiceUrl,RestTemplate restTemplate) {
		this.builder = new LogJSONBuilder(LOG).application(application).eventType(eventType);
		this.restClient = new RestClientUtility(builder, restTemplate,accredDataServiceUrl,engineServiceUrl);
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		String auth = request.getHeader("authorization");
		// validate the value in xAuth
		String requestURI = request.getRequestURI();
		String method = request.getMethod();
		try {
			boolean valid = isValid(auth, requestURI, method);
			if (valid) {
				filterChain.doFilter(request, response);
			}
		} catch (AccreditationAPIAccessException e) {
			ExceptionResponse exceptionResponse = new ExceptionResponse();
			exceptionResponse.setErrorCode(ErrorCode.AUTHORIZATION_ERROR);
			exceptionResponse.setErrorMessage(e.getMessage());
			ObjectMapper mapper = new ObjectMapper();
			String writeValueAsString = mapper.writeValueAsString(exceptionResponse);
			response.setContentType(MediaType.APPLICATION_JSON_VALUE);
			response.setStatus(HttpStatus.FORBIDDEN.value());
			PrintWriter writer = response.getWriter();
			writer.write(writeValueAsString);
			writer.flush();
		} catch (AccreditationAPICallFailedException e) {
			ObjectMapper mapper = new ObjectMapper();
			String writeValueAsString = mapper.writeValueAsString(e.getErrorResponse());
			response.setContentType(MediaType.APPLICATION_JSON_VALUE);
			response.setStatus(HttpStatus.UNAUTHORIZED.value());
			PrintWriter writer = response.getWriter();
			writer.write(writeValueAsString);
			writer.flush();
		}catch(AccreditationResourceAccessException e){
			ObjectMapper mapper = new ObjectMapper();
			String writeValueAsString = mapper.writeValueAsString(e.getErrorResponse());
			response.setContentType(MediaType.APPLICATION_JSON_VALUE);
			response.setStatus(e.getStatusCode().value());
			PrintWriter writer = response.getWriter();
			writer.write(writeValueAsString);
			writer.flush();
		}

	}

	private boolean isValid(String auth, String requestURI, String method)
			throws JsonParseException, JsonMappingException, IOException {
		String[] authParts = auth.split("\\s+");
		byte[] bytes = Base64.getDecoder().decode(authParts[1]);
		String string = new String(bytes);
		OrganizationAccess callAccreditatationDataApi = restClient.callAccreditatationDataApi(
				new HttpEntity<>(getHttpHeaders(string)), "accreditation/organization/apiaccesskey",
				OrganizationAccess.class, HttpMethod.GET);
		List<OrganizationApiAccess> apiAccessList = callAccreditatationDataApi.getApiAccessList();

		List<OrganizationApiAccess> collect = apiAccessList.stream()
				.filter(api -> HttpMethod.GET.toString().equals(api.getMethod())).collect(Collectors.toList());

		for (OrganizationApiAccess organizationApiAccess : collect) {
			UriTemplate template = new UriTemplate(organizationApiAccess.getUri());
			if (template.matches(requestURI)) {
				return true;
			}
		}
		// get all other requests except GET
		Optional<OrganizationApiAccess> findAny = apiAccessList.stream()
				.filter(api -> ! HttpMethod.GET.toString().equals(api.getMethod()))
				.filter(api -> api.getMethod().equals(method) && api.getUri().equals(requestURI)).findAny();
		if (!findAny.isPresent()) {
			throw new AccreditationAPIAccessException(
					"you don't have access to requested resource,please try with appropriate credentails to access the resource ");
		}
		return true;
	}

	private MultiValueMap<String, String> getHttpHeaders(String authHeader) {
		HttpHeaders map = new HttpHeaders();
		String[] split = authHeader.split(":");
		map.set("orgUserName", split[0]);
		map.set("apiAccessKey", split[1]);
		return map;
	}

}
