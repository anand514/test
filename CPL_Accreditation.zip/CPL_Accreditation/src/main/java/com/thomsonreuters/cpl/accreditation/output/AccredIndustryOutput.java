package com.thomsonreuters.cpl.accreditation.output;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredIndustryOutput {

	public AccredIndustryOutput(List<AccredIndustry> industries) {
		this.industries = industries;
	}

	public AccredIndustryOutput() {
	}

	private List<AccredIndustry> industries;

	public List<AccredIndustry> getIndustries() {
		return industries;
	}

	public void setIndustries(List<AccredIndustry> industries) {
		this.industries = industries;
	}
}
