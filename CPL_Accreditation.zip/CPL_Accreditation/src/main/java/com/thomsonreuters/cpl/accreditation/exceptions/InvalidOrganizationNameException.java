package com.thomsonreuters.cpl.accreditation.exceptions;

/**
 * if the given organization name is not found in the database , then we will
 * throw this exception
 * 
 * @author mohan
 *
 */
public class InvalidOrganizationNameException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidOrganizationNameException(String message) {
		super(message);
	}

	public InvalidOrganizationNameException(String message, Throwable t) {
		super(message, t);
	}

}
