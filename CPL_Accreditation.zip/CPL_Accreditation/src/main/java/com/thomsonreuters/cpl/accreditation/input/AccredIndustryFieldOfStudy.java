package com.thomsonreuters.cpl.accreditation.input;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.thomsonreuters.cpl.accreditation.common.AccredRegulatorCredit;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredIndustryFieldOfStudy {

	private int industryId;

	private int formatId;


	@NotEmpty
	@NotNull
	@Valid
	private List<AccredFieldOfStudy> fieldOfStudies;

//	@Valid
//	@NotNull
//	@NotEmpty
	private List<AccredQuestion> questions;

	@NotEmpty
	@NotNull
	private List<Integer> regulators;

	@Valid
	private List<AccredRegulatorCredit> updatedCredits;

	public int getIndustryId() {
		return industryId;
	}

	public void setIndustryId(int industryId) {
		this.industryId = industryId;
	}

	public List<AccredFieldOfStudy> getFieldOfStudies() {
		return fieldOfStudies;
	}

	public void setFieldOfStudies(List<AccredFieldOfStudy> fieldOfStudies) {
		this.fieldOfStudies = fieldOfStudies;
	}

	public List<AccredQuestion> getQuestions() {
		return questions;
	}

	public void setQuestions(List<AccredQuestion> questions) {
		this.questions = questions;
	}

	public List<Integer> getRegulators() {
		return regulators;
	}

	public void setRegulators(List<Integer> regulators) {
		this.regulators = regulators;
	}

	public int getFormatId() {
		return formatId;
	}

	public void setFormatId(int formatId) {
		this.formatId = formatId;
	}

	public List<AccredRegulatorCredit> getUpdatedCredits() {
		return updatedCredits;
	}

	public void setUpdatedCredits(List<AccredRegulatorCredit> updatedCredits) {
		this.updatedCredits = updatedCredits;
	}

}
