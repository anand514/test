package com.thomsonreuters.cpl.accreditation.web;

import javax.validation.Valid;

import org.apache.commons.lang3.time.StopWatch;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.thomsonreuters.cpl.accreditation.common.AccredCreditRegulatorOutput;
import com.thomsonreuters.cpl.accreditation.exceptions.AccreditationApplicationException;
import com.thomsonreuters.cpl.accreditation.input.AccredRegulatorCreditUpdateInput;
import com.thomsonreuters.cpl.accreditation.input.ContentDistributorInput;
import com.thomsonreuters.cpl.accreditation.input.CustomDateStringSerializer;
import com.thomsonreuters.cpl.accreditation.input.FieldOfStudyInput;
import com.thomsonreuters.cpl.accreditation.log.LogJSONBuilder;
import com.thomsonreuters.cpl.accreditation.log.LoggingConstants;
import com.thomsonreuters.cpl.accreditation.log.LoggingUtils;
import com.thomsonreuters.cpl.accreditation.log.LoggingUtils.Tuple;
import com.thomsonreuters.cpl.accreditation.output.AccredCEFormatOutput;
import com.thomsonreuters.cpl.accreditation.output.AccredCrediOutput;
import com.thomsonreuters.cpl.accreditation.output.AccredIndustryOutput;
import com.thomsonreuters.cpl.accreditation.output.ContentDistributorOutput;
import com.thomsonreuters.cpl.accreditation.utility.RestClientUtility;

import ch.qos.logback.classic.Level;

@RestController
public class AccreditationController {

	private static final Logger LOG = LoggerFactory.getLogger(AccreditationController.class);

	private static final String LOG_LAYER_LEVEL = "7777";

	private final LogJSONBuilder builder;

	private final RestClientUtility restClientUtiliity;

	@Autowired
	public AccreditationController(@Value("${eventType}") String eventType, @Value("${application}") String application,
			@Value("${accreditation.data.service.url}") String accredDataServiceUrl,
			@Value("${xmlrulesengine.service.url}") String engineServiceUrl, RestTemplate restTemplate) {
		builder = new LogJSONBuilder(LOG).application(application).className(AccreditationController.class.getName())
				.eventType(eventType);
		this.restClientUtiliity = new RestClientUtility(builder, restTemplate,accredDataServiceUrl,engineServiceUrl);

	}

	@CrossOrigin
	@RequestMapping(value = "/accreditation/deliveryformats", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public AccredCEFormatOutput getDeliveryFormats() throws AccreditationApplicationException {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		StopWatch stopWatch = new StopWatch();

		stopWatch.start();

		LoggingUtils.logMessage("request received to get the delivery formats", Level.INFO, LOG_LAYER_LEVEL, methodName,
				null, null, null, null, builder);

		LoggingUtils.logMessage("calling internal accreditation deliveryformats api to get the data", Level.INFO,
				LOG_LAYER_LEVEL, methodName, null, null, null, null, builder);

		AccredCEFormatOutput callAccreditatationDataApi = restClientUtiliity.callAccreditatationDataApi(null,
				"/accreditation/deliveryformats", AccredCEFormatOutput.class, HttpMethod.GET);

		stopWatch.stop();

		JSONObject responseJSONObject = LoggingUtils.getConvertedJSONObject(callAccreditatationDataApi, LOG_LAYER_LEVEL,
				builder, new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("got response from internal api, sending the respose back to client", Level.INFO,
				LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, responseJSONObject, null, builder);

		return callAccreditatationDataApi;
	}

	@CrossOrigin
	@RequestMapping(value = "/accreditation/regulators/{orgUserName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public AccredIndustryOutput getRegulators(@PathVariable(value = "orgUserName", required = true) String orgUserName)
			throws AccreditationApplicationException {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		StopWatch stopWatch = new StopWatch();

		stopWatch.start();

		JSONObject obj = new JSONObject();

		obj.put(LoggingConstants.LOGGING_MESSAGE, "request received to get the regulators for the organization");

		obj.put(LoggingConstants.ORG_USER_NAME, orgUserName);

		LoggingUtils.logMessage(obj, Level.INFO, LOG_LAYER_LEVEL, methodName, null, null, null, null, builder);

		LoggingUtils.logMessage("calling internal accreditation regulators api to get the data", Level.INFO,
				LOG_LAYER_LEVEL, methodName, null, null, null, null, builder);

		AccredIndustryOutput callAccreditatationDataApi = restClientUtiliity.callAccreditatationDataApi(null,
				"/accreditation/regulators/" + orgUserName, AccredIndustryOutput.class, HttpMethod.GET);

		stopWatch.stop();

		JSONObject responseJSONObject = LoggingUtils.getConvertedJSONObject(callAccreditatationDataApi, LOG_LAYER_LEVEL,
				builder, new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("got response from internal api, sending the respose back to client", Level.INFO,
				LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, responseJSONObject, null, builder);

		return callAccreditatationDataApi;
	}

	@CrossOrigin
	@RequestMapping(value = "/accreditation/fieldofstudies", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String getContentDistributors(@RequestBody @Valid ContentDistributorInput distributor)
			throws AccreditationApplicationException {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		StopWatch stopWatch = new StopWatch();

		stopWatch.start();

		JSONObject convertedJSONObject = LoggingUtils.getConvertedJSONObject(distributor, LOG_LAYER_LEVEL, builder,
				new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("request received to get the field of studies ", Level.INFO, LOG_LAYER_LEVEL,
				methodName, null, convertedJSONObject, null, null, builder);

		LoggingUtils.logMessage("calling internal accreditation fieldofstudies api to get the data", Level.INFO,
				LOG_LAYER_LEVEL, methodName, null, null, null, null, builder);

		ContentDistributorOutput output = restClientUtiliity.callRulesEngineAccreditaionAPI(distributor,
				"accreditation/fieldofstudies", ContentDistributorOutput.class, HttpMethod.POST);

		stopWatch.stop();

		JSONObject responseJSONObject = LoggingUtils.getConvertedJSONObject(output, LOG_LAYER_LEVEL, builder,
				new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("got response from internal api, sending the respose back to client", Level.INFO,
				LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, responseJSONObject, null, builder);

		return responseJSONObject.toString();
	}

	@CrossOrigin
	@RequestMapping(value = "/accreditation/creditstring", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String getCreditString(@RequestBody @Valid FieldOfStudyInput fieldOfStudyInput)
			throws AccreditationApplicationException {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		StopWatch stopWatch = new StopWatch();

		stopWatch.start();

		JSONObject convertedJSONObject = LoggingUtils.getConvertedJSONObject(fieldOfStudyInput, LOG_LAYER_LEVEL,
				builder, new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("request received to calcuate the credit string ", Level.INFO, LOG_LAYER_LEVEL,
				methodName, null, convertedJSONObject, null, null, builder);

		LoggingUtils.logMessage("calling internal accreditation credit string api to get the data", Level.INFO,
				LOG_LAYER_LEVEL, methodName, null, null, null, null, builder);

		AccredCrediOutput accredCrediOutput = restClientUtiliity.callRulesEngineAccreditaionAPI(fieldOfStudyInput,
				"accreditation/creditstring", AccredCrediOutput.class, HttpMethod.POST);

		stopWatch.stop();

		JSONObject responseJSONObject = LoggingUtils.getConvertedJSONObject(accredCrediOutput, LOG_LAYER_LEVEL, builder,
				new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("got response from internal api, sending the respose back to client", Level.INFO,
				LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, responseJSONObject, null, builder);

		return responseJSONObject.toString();
	}

	@CrossOrigin
	@RequestMapping(value = "/accreditation/creditstring", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String getCreditStringWithUpdates(@RequestBody @Valid AccredRegulatorCreditUpdateInput fieldOfStudyInput)
			throws AccreditationApplicationException {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		StopWatch stopWatch = new StopWatch();

		stopWatch.start();

		JSONObject convertedJSONObject = LoggingUtils.getConvertedJSONObject(fieldOfStudyInput, LOG_LAYER_LEVEL,
				builder, new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("request received to calcuate the credit string for updated credits ", Level.INFO,
				LOG_LAYER_LEVEL, methodName, null, convertedJSONObject, null, null, builder);

		LoggingUtils.logMessage("calling internal accreditation  updated credits api to get the data", Level.INFO,
				LOG_LAYER_LEVEL, methodName, null, null, null, null, builder);

		AccredCrediOutput callAccreditaionAPI = restClientUtiliity.callRulesEngineAccreditaionAPI(fieldOfStudyInput,
				"accreditation/creditstring", AccredCrediOutput.class, HttpMethod.PUT);

		stopWatch.stop();

		JSONObject responseJSONObject = LoggingUtils.getConvertedJSONObject(callAccreditaionAPI, LOG_LAYER_LEVEL,
				builder, new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("got response from internal api, sending the respose back to client", Level.INFO,
				LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, responseJSONObject, null, builder);

		return responseJSONObject.toString();
	}

	@CrossOrigin
	@RequestMapping(value = "/accreditation/credits", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String getCredits(@RequestBody @Valid FieldOfStudyInput fieldOfStudyInput)
			throws AccreditationApplicationException {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		StopWatch stopWatch = new StopWatch();

		stopWatch.start();

		JSONObject convertedJSONObject = LoggingUtils.getConvertedJSONObject(fieldOfStudyInput, LOG_LAYER_LEVEL,
				builder, new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("request received to calcuate the credits", Level.INFO, LOG_LAYER_LEVEL, methodName,
				null, convertedJSONObject, null, null, builder);

		LoggingUtils.logMessage("calling internal accreditation credits api to get the data", Level.INFO,
				LOG_LAYER_LEVEL, methodName, null, null, null, null, builder);

		AccredCreditRegulatorOutput accredRegulatorOutput = restClientUtiliity.callRulesEngineAccreditaionAPI(
				fieldOfStudyInput, "accreditation/credits", AccredCreditRegulatorOutput.class, HttpMethod.POST);

		stopWatch.stop();

		JSONObject responseJSONObject = LoggingUtils.getConvertedJSONObject(accredRegulatorOutput, LOG_LAYER_LEVEL,
				builder, new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("got response from internal api, sending the respose back to client", Level.INFO,
				LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, responseJSONObject, null, builder);

		return responseJSONObject.toString();

	}

	@CrossOrigin
	@RequestMapping(value = "/accreditation/creditsfromcreditstring", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String getCreditsFromCreditString(@RequestBody @Valid AccredCrediOutput fieldOfStudyInput)
			throws AccreditationApplicationException {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		StopWatch stopWatch = new StopWatch();

		stopWatch.start();

		JSONObject convertedJSONObject = LoggingUtils.getConvertedJSONObject(fieldOfStudyInput, LOG_LAYER_LEVEL,
				builder, new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("request received to get the credits from credit string", Level.INFO, LOG_LAYER_LEVEL,
				methodName, null, convertedJSONObject, null, null, builder);

		LoggingUtils.logMessage("calling internal accreditation credits api to get the data", Level.INFO,
				LOG_LAYER_LEVEL, methodName, null, null, null, null, builder);

		AccredCreditRegulatorOutput accredRegulatorOutput = restClientUtiliity.callRulesEngineAccreditaionAPI(
				fieldOfStudyInput, "/accreditation/creditsfromcreditstring", AccredCreditRegulatorOutput.class,
				HttpMethod.POST);

		stopWatch.stop();

		JSONObject responseJSONObject = LoggingUtils.getConvertedJSONObject(accredRegulatorOutput, LOG_LAYER_LEVEL,
				builder, new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("got response from internal api, sending the respose back to client", Level.INFO,
				LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, responseJSONObject, null, builder);

		return responseJSONObject.toString();

	}

}
