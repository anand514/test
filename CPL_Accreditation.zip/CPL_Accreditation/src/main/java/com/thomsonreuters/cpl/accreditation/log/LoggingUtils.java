package com.thomsonreuters.cpl.accreditation.log;

import java.time.LocalDateTime;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.jboss.logging.MDC;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

import ch.qos.logback.classic.Level;

/**
 * 
 * @author u6033361
 *
 */
public class LoggingUtils {

	public static void logMessage(String loggingMessage, Level severity, String logLevel, String methdoName,
			Long executionTime, JSONObject request, JSONObject response, String exceptionStackTrace,
			LogJSONBuilder builder) {
		JSONObject build = builder.build();
		build.put(LoggingConstants.LOGGING_MESSAGE, loggingMessage);
		addAdditionalParameters(build, severity, logLevel, executionTime, request, response, exceptionStackTrace,
				methdoName);
		log(builder.getLogger(), build);

	}

	private static void addAdditionalParameters(JSONObject build, Level severity, String logLevel, Long executionTime,
			JSONObject request, JSONObject response, String exceptionStackTrace, String methdoName) {
		build.put(LoggingConstants.METHOD_NAME, methdoName);
		build.put(LoggingConstants.SEVERITY, severity.toString());
		build.put(LoggingConstants.LOG_LEVEL, logLevel);
		if (executionTime != null) {
			build.put(LoggingConstants.EXECUTION_TIME, executionTime + " milliseconds");
		}
		build.put(LoggingConstants.INPUT_FOR_METHOD, request);
		build.put(LoggingConstants.OUTPUT_FROM_METHOD, response);
		build.put(LoggingConstants.STACK_TRACE, exceptionStackTrace);
	}

	public static void logMessage(JSONObject loggingMessageObj, Level severity, String logLevel, String methodName,
			Long executionTime, JSONObject request, JSONObject response, String exceptionStackTrace,
			LogJSONBuilder builder) {
		JSONObject build = builder.build();
		build.put(LoggingConstants.LOGGING_MESSAGE_OBJ, loggingMessageObj);
		addAdditionalParameters(build, severity, logLevel, executionTime, request, response, exceptionStackTrace,
				methodName);
		log(builder.getLogger(), build);

	}

	private static void log(Logger log, JSONObject jsonObj) {
		jsonObj.put(LoggingConstants.TIME_STAMP, LocalDateTime.now().toString());

		MDC.put(LoggingConstants.LEARN_LIVE_LOG, jsonObj.toString());

		String severity = null;
		try {
			severity = jsonObj.getString(LoggingConstants.SEVERITY);
		} catch (JSONException e) {
			log.error("severity key is not there, no issues , lets proceed further", e);
		}
		if (severity == null || severity.equals(Level.INFO.toString())) {
			log.info(LoggingConstants.XML_RULES_ENGINE_COMPLIANCE_REQUESTS);
			return;
		}
		if (severity.equals(Level.DEBUG.toString())) {
			log.debug(LoggingConstants.XML_RULES_ENGINE_COMPLIANCE_REQUESTS);
		}
		if (severity.equals(Level.ERROR.toString())) {
			log.error(LoggingConstants.XML_RULES_ENGINE_COMPLIANCE_REQUESTS);
		}
		if (severity.equals(Level.TRACE.toString())) {
			log.trace(LoggingConstants.XML_RULES_ENGINE_COMPLIANCE_REQUESTS);
		}
	}

	@SuppressWarnings("unchecked")
	public static JSONObject getConvertedJSONObject(Object input, String logLayerLevel, LogJSONBuilder builder,
			Tuple<?>... tuples) {
		if(input==null){
			// no need to convert anything , return null if input is null
			return null;
		}
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		ObjectMapper mapper = new ObjectMapper();
		SimpleModule module = new SimpleModule();
		for (@SuppressWarnings("rawtypes") Tuple tuple : tuples) {
			module.addSerializer(tuple.type, tuple.serializer);
		}
		mapper.registerModule(module);
		String writeValueAsString = null;
		try {
			writeValueAsString = mapper.writeValueAsString(input);
		} catch (JsonProcessingException e) {
			String stackTrace = ExceptionUtils.getStackTrace(e);
			LoggingUtils.logMessage("unable to create the json string from the object ", Level.ERROR, logLayerLevel,
					methodName, null, null, null, stackTrace, builder);
		}
		return new JSONObject(writeValueAsString);

	}

	public static class Tuple<T> {
		Class<T> type;
		JsonSerializer<T> serializer;

		public Tuple(Class<T> type, JsonSerializer<T> serializer) {
			this.type = type;
			this.serializer = serializer;
		}
	}

}
