package com.thomsonreuters.cpl.accreditation.log;

import java.util.Map;

import org.json.JSONObject;

import ch.qos.logback.classic.pattern.ThrowableProxyConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.core.CoreConstants;
import ch.qos.logback.core.LayoutBase;
import ch.qos.logback.core.util.CachingDateFormatter;

/**
 * this class is useful to log the json logging messages to console
 * 
 * @author mohan reddy
 *
 */
public class EngineCustomConsoleJsonEventLayout extends LayoutBase<ILoggingEvent> {

	private static CachingDateFormatter cachingDateFormatter = new CachingDateFormatter(CoreConstants.ISO8601_PATTERN);

	private static ThrowableProxyConverter tpc = new ThrowableProxyConverter();

	@Override
	public String doLayout(ILoggingEvent event) {
		if (!isStarted()) {
			return CoreConstants.EMPTY_STRING;
		}
		StringBuilder sb = new StringBuilder();

		long timestamp = event.getTimeStamp();

		sb.append(cachingDateFormatter.format(timestamp));
		sb.append(" [");
		sb.append(event.getThreadName());
		sb.append("] ");
		sb.append(event.getLevel().toString());
		sb.append(" ");
		sb.append(event.getLoggerName());
		sb.append(" - ");

		Map<String, String> mdcPropertyMap = event.getMDCPropertyMap();

		String formattedMessage = event.getFormattedMessage();

		if (formattedMessage != null
				&& LoggingConstants.XML_RULES_ENGINE_COMPLIANCE_REQUESTS.equals(formattedMessage)) {

			if (!mdcPropertyMap.isEmpty()) {
				JSONObject jsonObject = new JSONObject(mdcPropertyMap);
				sb.append(jsonObject.toString());
			}
		} else {
			sb.append(event.getFormattedMessage());
		}

		sb.append(CoreConstants.LINE_SEPARATOR);
		IThrowableProxy tp = event.getThrowableProxy();
		if (tp != null) {
			String stackTrace = tpc.convert(event);
			sb.append(stackTrace);
		}
		return sb.toString();
	}

}
