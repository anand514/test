package com.thomsonreuters.cpl.accreditation.utility;

import java.io.IOException;

import org.apache.commons.lang3.time.StopWatch;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.thomsonreuters.cpl.accreditation.exceptions.AccreditationAPICallFailedException;
import com.thomsonreuters.cpl.accreditation.exceptions.AccreditationApplicationException;
import com.thomsonreuters.cpl.accreditation.exceptions.AccreditationResourceAccessException;
import com.thomsonreuters.cpl.accreditation.exceptions.ExceptionResponse;
import com.thomsonreuters.cpl.accreditation.exceptions.ExceptionResponse.ErrorCode;
import com.thomsonreuters.cpl.accreditation.input.CustomDateStringSerializer;
import com.thomsonreuters.cpl.accreditation.log.LogJSONBuilder;
import com.thomsonreuters.cpl.accreditation.log.LoggingUtils;
import com.thomsonreuters.cpl.accreditation.log.LoggingUtils.Tuple;

import ch.qos.logback.classic.Level;

public class RestClientUtility {

	private static final String LOG_LAYER_LEVEL = "7776";

	private RestTemplate restTemplate;

	private LogJSONBuilder builder;

	private String accreditationDataServiceUrl;

	private String rulesEngineServiceUrl;

	public RestClientUtility(LogJSONBuilder builder, RestTemplate restTemplate, String accredDataServiceUrl,
			String engineServiceUrl) {
		this.restTemplate = restTemplate;
		this.builder = builder;
		this.accreditationDataServiceUrl = accredDataServiceUrl;
		this.rulesEngineServiceUrl = engineServiceUrl;
	}

	public <T> T callRulesEngineAccreditaionAPI(Object entity, String API_URl, Class<T> responseType,
			HttpMethod httpMethod) throws AccreditationApplicationException {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		StopWatch stopWatch = new StopWatch();

		stopWatch.start();

		JSONObject convertedJSONObject = LoggingUtils.getConvertedJSONObject(entity, LOG_LAYER_LEVEL, builder,
				new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("calling API with URL " + API_URl, Level.INFO, LOG_LAYER_LEVEL, methodName, null,
				convertedJSONObject, null, null, builder);

		HttpEntity<?> httpEntity = new HttpEntity<>(entity);
		ObjectMapper mapper = new ObjectMapper();

		try {
			ResponseEntity<String> exchange = restTemplate.exchange(rulesEngineServiceUrl + API_URl, httpMethod,
					httpEntity, String.class);
			try {
				T readValue = mapper.readValue(exchange.getBody(), responseType);

				stopWatch.stop();

				JSONObject responseObject = LoggingUtils.getConvertedJSONObject(readValue, LOG_LAYER_LEVEL, builder,
						new Tuple<String>(String.class, new CustomDateStringSerializer()));

				LoggingUtils.logMessage("got response from  API with URL " + API_URl, Level.INFO, LOG_LAYER_LEVEL,
						methodName, stopWatch.getTime(), null, responseObject, null, builder);

				return readValue;
			} catch (IOException e) {
				stopWatch.stop();
				LoggingUtils.logMessage("failed to read success response body" + API_URl, Level.INFO, LOG_LAYER_LEVEL,
						methodName, stopWatch.getTime(), null, null, null, builder);
				throw new AccreditationApplicationException("failed to read success response body", e);
			}
		} catch (HttpStatusCodeException e) {
			stopWatch.stop();
			try {
				ExceptionResponse readValue = mapper.readValue(e.getResponseBodyAsString(), ExceptionResponse.class);

				JSONObject responseObject = LoggingUtils.getConvertedJSONObject(readValue, LOG_LAYER_LEVEL, builder,
						new Tuple<String>(String.class, new CustomDateStringSerializer()));

				LoggingUtils.logMessage(
						"request failed from server ,throwing exception with the error response received " + API_URl,
						Level.INFO, LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, responseObject, null,
						builder);

				throw new AccreditationAPICallFailedException(e.getMessage(), readValue, e.getStatusCode(), e);
			} catch (IOException e1) {
				throw new AccreditationApplicationException("failed to read success response body", e1);
			}

		} catch (ResourceAccessException e) {
			stopWatch.stop();

			LoggingUtils.logMessage(
					"request failed from internal server ,throwing exception with the error received from the api with url "
							+ API_URl,
					Level.ERROR, LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, null, null, builder);

			ExceptionResponse exceptionResponse = new ExceptionResponse(ErrorCode.UNKNOWN_ERROR,
					"The server encountered an internal server error and was unable to complete your request , please contact server administrator and inform them of the time of error occured , and anything you might have done that may have caused the error  ");
			// TODO add server administrator name
			throw new AccreditationResourceAccessException(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR, e);

		}
	}

	public <T> T callAccreditatationDataApi(HttpEntity<?> httpEntity, String API_URl, Class<T> responseType,
			HttpMethod httpMethod) throws AccreditationApplicationException {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		StopWatch stopWatch = new StopWatch();

		stopWatch.start();

		JSONObject convertedJSONObject = LoggingUtils.getConvertedJSONObject(
				httpEntity == null ? null : httpEntity.getBody(), LOG_LAYER_LEVEL, builder,
				new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("calling API with URL " + API_URl, Level.INFO, LOG_LAYER_LEVEL, methodName, null,
				convertedJSONObject, null, null, builder);

		ObjectMapper mapper = new ObjectMapper();

		try {
			ResponseEntity<String> exchange = restTemplate.exchange(accreditationDataServiceUrl + API_URl, httpMethod,
					httpEntity, String.class);
			try {

				T readValue = mapper.readValue(exchange.getBody(), responseType);

				stopWatch.stop();

				JSONObject responseObject = LoggingUtils.getConvertedJSONObject(readValue, LOG_LAYER_LEVEL, builder,
						new Tuple<String>(String.class, new CustomDateStringSerializer()));

				LoggingUtils.logMessage("got response from  API with URL " + API_URl, Level.INFO, LOG_LAYER_LEVEL,
						methodName, stopWatch.getTime(), null, responseObject, null, builder);

				return readValue;
			} catch (IOException e) {
				stopWatch.stop();
				LoggingUtils.logMessage("failed to read success response body" + API_URl, Level.ERROR, LOG_LAYER_LEVEL,
						methodName, stopWatch.getTime(), null, null, null, builder);
				throw new AccreditationApplicationException("failed to read success response body", e);
			}
		} catch (HttpStatusCodeException e) {
			stopWatch.stop();
			try {
				ExceptionResponse readValue = mapper.readValue(e.getResponseBodyAsString(), ExceptionResponse.class);

				JSONObject responseObject = LoggingUtils.getConvertedJSONObject(readValue, LOG_LAYER_LEVEL, builder,
						new Tuple<String>(String.class, new CustomDateStringSerializer()));

				LoggingUtils.logMessage(
						"request failed from server ,throwing exception with the error response received " + API_URl,
						Level.ERROR, LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, responseObject, null,
						builder);

				throw new AccreditationAPICallFailedException(e.getMessage(), readValue, e.getStatusCode(), e);
			} catch (IOException e1) {
				throw new AccreditationApplicationException("failed to read success response body", e1);
			}

		} catch (ResourceAccessException e) {
			stopWatch.stop();

			LoggingUtils.logMessage(
					"request failed from internal server ,throwing exception with the error received from the api with url "
							+ API_URl,
					Level.ERROR, LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, null, null, builder);

			ExceptionResponse exceptionResponse = new ExceptionResponse(ErrorCode.UNKNOWN_ERROR,
					"The server encountered an internal server error and was unable to complete your request , please contact server administrator and inform them of the time of error occured , and anything you might have done that may have caused the error  ");
			// TODO add server administrator name
			throw new AccreditationResourceAccessException(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR, e);

		}
	}

	public <T> T callAccreditatationDataApiWithHeaders(Object entity, String API_URl, Class<T> responseType,
			HttpMethod httpMethod) throws AccreditationApplicationException {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();

		StopWatch stopWatch = new StopWatch();

		stopWatch.start();

		JSONObject convertedJSONObject = LoggingUtils.getConvertedJSONObject(entity, LOG_LAYER_LEVEL, builder,
				new Tuple<String>(String.class, new CustomDateStringSerializer()));

		LoggingUtils.logMessage("calling API with URL " + API_URl, Level.INFO, LOG_LAYER_LEVEL, methodName, null,
				convertedJSONObject, null, null, builder);

		HttpEntity<?> httpEntity = null;

		if (entity != null) {
			httpEntity = new HttpEntity<>(entity);
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			ResponseEntity<String> exchange = restTemplate.exchange(accreditationDataServiceUrl + API_URl, httpMethod,
					httpEntity, String.class);
			try {

				T readValue = mapper.readValue(exchange.getBody(), responseType);

				stopWatch.stop();

				JSONObject responseObject = LoggingUtils.getConvertedJSONObject(readValue, LOG_LAYER_LEVEL, builder,
						new Tuple<String>(String.class, new CustomDateStringSerializer()));

				LoggingUtils.logMessage("got response from  API with URL " + API_URl, Level.INFO, LOG_LAYER_LEVEL,
						methodName, stopWatch.getTime(), null, responseObject, null, builder);

				return readValue;
			} catch (IOException e) {
				stopWatch.stop();
				LoggingUtils.logMessage("failed to read success response body" + API_URl, Level.INFO, LOG_LAYER_LEVEL,
						methodName, stopWatch.getTime(), null, null, null, builder);
				throw new AccreditationApplicationException("failed to read success response body", e);
			}
		} catch (HttpStatusCodeException e) {
			stopWatch.stop();
			try {
				ExceptionResponse readValue = mapper.readValue(e.getResponseBodyAsString(), ExceptionResponse.class);

				JSONObject responseObject = LoggingUtils.getConvertedJSONObject(readValue, LOG_LAYER_LEVEL, builder,
						new Tuple<String>(String.class, new CustomDateStringSerializer()));

				LoggingUtils.logMessage(
						"request failed from server ,throwing exception with the error response received " + API_URl,
						Level.INFO, LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, responseObject, null,
						builder);

				throw new AccreditationAPICallFailedException(e.getMessage(), readValue, e.getStatusCode(), e);
			} catch (IOException e1) {
				throw new AccreditationApplicationException("failed to read success response body", e1);
			}

		} catch (ResourceAccessException e) {
			stopWatch.stop();

			LoggingUtils.logMessage(
					"request failed from internal server ,throwing exception with the error received from the api with url "
							+ API_URl,
					Level.ERROR, LOG_LAYER_LEVEL, methodName, stopWatch.getTime(), null, null, null, builder);

			ExceptionResponse exceptionResponse = new ExceptionResponse(ErrorCode.UNKNOWN_ERROR,
					"The server encountered an internal server error and was unable to complete your request , please contact server administrator and inform them of the time of error occured , and anything you might have done that may have caused the error  ");
			// TODO add server administrator name
			throw new AccreditationResourceAccessException(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR, e);

		}
	}
}
