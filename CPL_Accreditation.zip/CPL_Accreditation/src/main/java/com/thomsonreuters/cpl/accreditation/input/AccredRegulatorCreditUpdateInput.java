package com.thomsonreuters.cpl.accreditation.input;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.thomsonreuters.cpl.accreditation.common.AccredRegulatorCredit;

@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredRegulatorCreditUpdateInput {

	@NotNull(message = "creditString is required")
	private String creditString;

	@NotNull(message = "updatedCredits is required")
	@NotEmpty(message = "At least one regulator credits is required")
	private List<AccredRegulatorCredit> updatedCredits;

	public String getCreditString() {
		return creditString;
	}

	public void setCreditString(String creditString) {
		this.creditString = creditString;
	}

	public List<AccredRegulatorCredit> getUpdatedCredits() {
		return updatedCredits;
	}

	public void setUpdatedCredits(List<AccredRegulatorCredit> updatedCredits) {
		this.updatedCredits = updatedCredits;
	}

}
