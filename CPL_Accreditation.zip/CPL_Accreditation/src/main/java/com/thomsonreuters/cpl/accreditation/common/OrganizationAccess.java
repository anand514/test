package com.thomsonreuters.cpl.accreditation.common;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class OrganizationAccess {

	private List<OrganizationApiAccess> apiAccessList;

	public List<OrganizationApiAccess> getApiAccessList() {
		return apiAccessList;
	}

	public void setApiAccessList(List<OrganizationApiAccess> apiAccessList) {
		this.apiAccessList = apiAccessList;
	}

}
