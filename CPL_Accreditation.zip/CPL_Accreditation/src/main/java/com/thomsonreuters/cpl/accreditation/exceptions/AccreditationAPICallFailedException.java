package com.thomsonreuters.cpl.accreditation.exceptions;

import org.springframework.http.HttpStatus;

public class AccreditationAPICallFailedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private ExceptionResponse errorResponse;

	private HttpStatus statusCode;

	public AccreditationAPICallFailedException(String message) {
		super(message);
	}

	public AccreditationAPICallFailedException(String message, Throwable t) {
		super(message, t);
	}

	public AccreditationAPICallFailedException(String message, ExceptionResponse response, HttpStatus statusCode,
			Throwable t) {
		super(message);
		this.errorResponse = response;
		this.statusCode = statusCode;
	}

	public ExceptionResponse getErrorResponse() {
		return errorResponse;
	}

	public HttpStatus getStatusCode() {
		return statusCode;
	}

}
