package com.thomsonreuters.cpl.accreditation;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.support.BasicAuthorizationInterceptor;
import org.springframework.web.client.RestTemplate;

@Configuration
public class AppResourceConfig {
	/**
	 * spring.datasource.url=jdbc:sqlserver://fw-cpl-qa1-sql.tlr.thomson.com:1433;DatabaseName=CPL_QA1B
	 * spring.datasource.username=cpl_user spring.datasource.password=P@ssword1
	 * spring.datasource.driverClassName=com.microsoft.sqlserver.jdbc.SQLServerDriver
	 * 
	 * @return
	 */

	@Bean
	@Primary
	public DataSource dataSource() {
		return DataSourceBuilder.create().username("cpl_user").password("P@ssword1")
				.url("jdbc:sqlserver://fw-cpl-qa1-sql.tlr.thomson.com:1433;DatabaseName=CPL_QA1B")
				.driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver").build();
	}

	@Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getInterceptors().add(new BasicAuthorizationInterceptor("admin", "manage"));
		return restTemplate;
	}
}
