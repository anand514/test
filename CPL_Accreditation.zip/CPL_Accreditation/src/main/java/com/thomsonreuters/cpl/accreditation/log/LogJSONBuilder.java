package com.thomsonreuters.cpl.accreditation.log;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.json.JSONObject;
import org.slf4j.Logger;

public class LogJSONBuilder {

	private String application;

	private String eventType;

	private String className;

	private Logger LOG;

	private String ipAddress;

	private String hostName;

	public LogJSONBuilder(Logger log) {
		LOG = log;
		try {
			InetAddress localHost = InetAddress.getLocalHost();
			ipAddress = localHost.getHostAddress();
			hostName = localHost.getHostName();
		} catch (UnknownHostException e) {
			LOG.error("unable to get ip address and hostname", e);
		}
	}

	public LogJSONBuilder application(String application) {
		this.application = application;
		return this;
	}

	public LogJSONBuilder eventType(String eventType) {
		this.eventType = eventType;
		return this;
	}

	public LogJSONBuilder className(String className) {
		this.className = className;
		return this;
	}

	public JSONObject build() {
		JSONObject obj = new JSONObject();
		obj.put(LoggingConstants.APPLICATION, application);
		obj.put(LoggingConstants.EVENT_TYPE, eventType);
		obj.put(LoggingConstants.CLASS_NAME, className);
		obj.put(LoggingConstants.IP_ADDRESS, ipAddress);
		obj.put(LoggingConstants.HOST_NAME, hostName);
		return obj;
	}

	public Logger getLogger() {
		return LOG;
	}

}
