package com.thomsonreuters.cpl.accreditation.common;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredCreditRegulatorOutput {

	private List<AccredRegulatorCredit> credits;

	public List<AccredRegulatorCredit> getCredits() {
		return credits;
	}

	public void setCredits(List<AccredRegulatorCredit> credits) {
		this.credits = credits;
	}
}
