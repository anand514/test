package com.thomsonreuters.cpl.accreditation.exceptions;

import org.springframework.http.HttpStatus;

/**
 * when the accreditation micro service unable to access internal micro
 * services, this exception will be thrown.
 * 
 * @author mohan reddy
 *
 */
public class AccreditationResourceAccessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private ExceptionResponse errorResponse;

	private HttpStatus statusCode;

	public AccreditationResourceAccessException(String message) {
		super(message);
	}

	public AccreditationResourceAccessException(String message, Throwable t) {
		super(message, t);
	}

	public AccreditationResourceAccessException(ExceptionResponse response, HttpStatus statusCode, Throwable t) {
		super(response.getErrorMessage(), t);
		this.setErrorResponse(response);
		this.setStatusCode(statusCode);

	}

	public ExceptionResponse getErrorResponse() {
		return errorResponse;
	}

	public void setErrorResponse(ExceptionResponse errorResponse) {
		this.errorResponse = errorResponse;
	}

	public HttpStatus getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(HttpStatus statusCode) {
		this.statusCode = statusCode;
	}

}
