package com.thomsonreuters.cpl.accreditation.common;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredCategoryCredit {

	public AccredCategoryCredit() {

	}

	public AccredCategoryCredit(String category, Float credit) {
		this.category = category;
		this.credit = credit;
	}

	private String category;

	private Float credit;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Float getCredit() {
		return credit;
	}

	public void setCredit(Float credit) {
		this.credit = credit;
	}
}
