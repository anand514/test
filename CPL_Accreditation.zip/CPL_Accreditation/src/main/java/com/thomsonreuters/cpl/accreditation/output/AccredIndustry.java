package com.thomsonreuters.cpl.accreditation.output;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredIndustry {

	private int industryId;

	private List<AccredRegulator> regulators;

	public List<AccredRegulator> getRegulators() {
		return regulators;
	}

	public void setRegulators(List<AccredRegulator> regulators) {
		this.regulators = regulators;
	}

	public int getIndustryId() {
		return industryId;
	}

	public void setIndustryId(int industryId) {
		this.industryId = industryId;
	}
}
