package com.thomsonreuters.cpl.accreditation.log;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.LoggerContextListener;
import ch.qos.logback.core.Context;
import ch.qos.logback.core.spi.ContextAwareBase;
import ch.qos.logback.core.spi.LifeCycle;

/**
 * this class will read the data from environmental variables and set data to
 * the logging context
 * 
 * @author mohan reddy
 *
 */
public class LoggerStartupListener extends ContextAwareBase implements LoggerContextListener, LifeCycle {

	private boolean started = false;

	private boolean isTrElkLoggingEnabled = true;

	private static final String ENABLE_TR_LOGGING = "ENABLE_TR_LOGGING";

	private static final String IS_TR_LOGGING_ENABLED = "IS_TR_LOGGING_ENABLED";

	@Override
	public void start() {
		if (started)
			return;
		String isTrLoggingEnabled = System.getenv(ENABLE_TR_LOGGING);

		if (isTrLoggingEnabled != null) {
			isTrElkLoggingEnabled = Boolean.valueOf(isTrLoggingEnabled);
		}

		Context context = getContext();

		context.putProperty(IS_TR_LOGGING_ENABLED, String.valueOf(isTrElkLoggingEnabled));

		started = true;

	}

	@Override
	public void stop() {

	}

	@Override
	public boolean isStarted() {
		return started;
	}

	@Override
	public boolean isResetResistant() {
		return true;
	}

	@Override
	public void onStart(LoggerContext context) {

	}

	@Override
	public void onReset(LoggerContext context) {

	}

	@Override
	public void onStop(LoggerContext context) {

	}

	@Override
	public void onLevelChange(Logger logger, Level level) {

	}

}
