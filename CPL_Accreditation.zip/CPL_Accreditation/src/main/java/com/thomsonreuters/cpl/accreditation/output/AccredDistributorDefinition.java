package com.thomsonreuters.cpl.accreditation.output;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredDistributorDefinition {
	
	private int industryId;

	private List<AccredContentField> contentFields;

	private List<AccredQuestionField> questions;

	public List<AccredContentField> getContentFields() {
		return contentFields;
	}

	public void setContentFields(List<AccredContentField> contentFields) {
		this.contentFields = contentFields;
	}

	public List<AccredQuestionField> getQuestions() {
		return questions;
	}

	public void setQuestions(List<AccredQuestionField> questions) {
		this.questions = questions;
	}

	public int getIndustryId() {
		return industryId;
	}

	public void setIndustryId(int industryId) {
		this.industryId = industryId;
	}
}
