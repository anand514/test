package com.thomsonreuters.cpl.accreditation.output;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredCrediOutput {

	private String creditString;

	public String getCreditString() {
		return creditString;
	}

	public void setCreditString(String creditString) {
		this.creditString = creditString;
	}
}
