package com.thomsonreuters.cpl.accreditation.exceptions;

/**
 * Thrown if an request is rejected because for the given credentials don't have
 * access to the requested api
 * 
 * @author mohan
 * 
 */
public class AccreditationAPIAccessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccreditationAPIAccessException(String message) {
		super(message);
	}

	public AccreditationAPIAccessException(String message, Throwable t) {
		super(message, t);
	}

}
