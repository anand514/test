package com.thomsonreuters.cpl.accreditation.output;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.thomsonreuters.cpl.accreditation.common.AccredRegulatorCredit;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredCreditOutput {
	private List<AccredRegulatorCredit> response;

	public List<AccredRegulatorCredit> getResponse() {
		return response;
	}

	public void setResponse(List<AccredRegulatorCredit> response) {
		this.response = response;
	}
}
