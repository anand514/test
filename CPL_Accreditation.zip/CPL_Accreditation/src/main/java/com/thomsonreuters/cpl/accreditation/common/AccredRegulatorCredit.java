package com.thomsonreuters.cpl.accreditation.common;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class AccredRegulatorCredit {

	private int regulatorId;

	private String type;

	private String pType;

	private boolean approval;

	private List<AccredCategoryCredit> categoryCredits;

	private List<AccredProperty> properties;

	public int getRegulatorId() {
		return regulatorId;
	}

	public void setRegulatorId(int regulatorId) {
		this.regulatorId = regulatorId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getpType() {
		return pType;
	}

	public void setpType(String pType) {
		this.pType = pType;
	}

	public boolean isApproval() {
		return approval;
	}

	public void setApproval(boolean approval) {
		this.approval = approval;
	}

	public List<AccredCategoryCredit> getCategoryCredits() {
		return categoryCredits;
	}

	public void setCategoryCredits(List<AccredCategoryCredit> categoryCredits) {
		this.categoryCredits = categoryCredits;
	}

	public List<AccredProperty> getProperties() {
		return properties;
	}

	public void setProperties(List<AccredProperty> properties) {
		this.properties = properties;
	}

}
