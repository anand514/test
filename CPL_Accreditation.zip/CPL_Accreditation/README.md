# Accreditation Utility
Accreditation Utility helps the customers in generating the credit string for the desired course, selected regulator and field Of Studies in an encoded format.

### What you will need to setup the project in your local
- [JAVA 8](http://www.oracle.com/technetwork/java/javase/downloads/index.html) or higher
- [GIT](https://git-scm.com/downloads)
- [STS](https://spring.io/tools/sts/all)

### Clone the repo
-	https://git.sami.int.thomsonreuters.com/tr/cpl-accreditation-webapi.git
    
### STS Project Setup
- open the sts(spring tool suite)
- click on the file menu and click on the import project 
- then select the existing maven projects and then give the path of the project that you just cloned
- then click finish and then project will build automatically. 
- then right click on the project and run as spring boot application , it will run on the port defined in the application.properties.

### Accreditation Utility API End Points

- [Delivery Formats API](/docs/deliveryformats/DeliveryFormats.md)
- [Credits API](/docs/credits/Credits.md)
- [Field of studies API](/docs/fieldofstudies/FieldOfStudies.md)
- [Organization regulators API](/docs/organizationregulators/OrganizationRegulators.md)
- [Credit string API(POST Request)](/docs/creditstring/post/CreditString.md)
- [Credit string API(PUT Request)](/docs/creditstring/put/CreditString.md)
- [Credits from credit string API](/docs/creditsfromcreditstring/CreditsFromCreditString.md) 


### API's Accessing Order
-	[API's Accessing Order](docs/accreditationservicesaccessorder/Accreditation_Services_Access_Order.md)

### Architecture Diagram
![Accreditation micro service internal flow](/docs/Accreditation_Utility_Service_Flow.png)

-	Accreditation micro service internally interacts with Accreditation Data MicroService and XML Rules Engine Micro Service

-	Accreditation Data MicroService interacts with the database to get the data required for the Accreditation MicroService.

-	XML Rules Engine MicroService calculates the credits based on the given hours and question answers.