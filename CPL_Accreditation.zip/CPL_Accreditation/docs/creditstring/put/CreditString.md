# CreditString
this api will give the calculated credit string in the encoded format for the given credits
### URI
    /accreditation/creditstring
### Method
    PUT
### Auth Required
    YES
### Resource and Query Parameters
    None
### Header Parameters
#### Supplying basic auth headers
If you need to you may construct and send basic auth headers yourself. To do this you need to perform the following steps:

-   Build a string of the form username:password
-   Base64 encode the string
-   Supply an “Authorization” header with content “Basic ” followed by the encoded string. For        example, the string fred:fred encodes to ZnJlZDpmcmVk in base64, so you would make the           request  using that header
-   username is the organization username 
-   password is the secret key given for the organization

### Request Body
Parameter Name | Data Type | Description
-| -|-
creditString  | string | encoded credit string 
updatedCredits  | array of updated credit objects |  updated credit objects that you want to update the credits
updatedCredits.regulatorId | integer | regulator id or jurisdiction id 
updatedCredits.type  | string | format of the updated credit type 
updatedCredits.pType | string | ptype
updatedCredits.approval | boolean | approval
updatedCredits.categoryCredits | array of credit objects | array of credit objects for which you want to update the credits
updatedCredits.categoryCredits.category |string| credit category
updatedCredits.categoryCredits.credit | integer | updated credit value
updatedCredits.properties | array of properties objects | array of properties 
#### sample request body

```json
{
	"creditString": "56c61746f723e3c526567756c61746f722069643d22313632223e3c437265646974735f3220747970653d224c6976652220617070726f76616c3d2274727565223e3c4372656469742063617465676f72793d22534b222076616c75653d22332e30222f3e3c4372656469742063617465676f72793d225458222076616c75653d22312e30222f3e3c4372656469742063617465676f72793d224d54222076616c75653d22342e30222f3e3c4372656469742063617465676f72793d2247656e222076616c75653d22322e30222f3e3c4372656469742063617465676f72793d22457468222076616c75653d22322e30222f3e3c4372656469742063617465676f72793d22476f76222076616c75653d22352e30222f3e3c4372656469742063617465676f72793d224141222076616c75653d22332e30222f3e3c2f437265646974735f323e3c2f526567756c61746f723e3c52",
	"updatedCredits": [
		{
			"regulatorId": 190,
			"type": "Live",
			"pType": "",
			"approval": true,
			"categoryCredits": [
				{
					"category": "TX",
					"credit": 1
				},
				{
					"category": "Gen",
					"credit": 9
				}
			],
			"properties": []
		}
	]
}
```

###  Success Response
-  Status Code: 200
-  Sample Success Response Body : 
```
  {
    "creditString": "EK016769324e53693c437265646974735f323e3c526567756c61746f722069643d22323137223e3c437265646974735f3220747970653d224c6976652220617070726f76616c3d2274727565223e3c2f437265646974735f323e3c2f526567756c61746f723e3c4669656c644f665374756479496e7075743e3c696e7075743e3c696e64757374727949643e313c2f696e64757374727949643e3c666f726d617449643e313c2f666f726d617449643e3c6669656c644f66537475646965733e3c6669656c644f66537475646965733e3c6b65793e315f303c2f6b65793e3c76616c75653e3130303c2f76616c75653e3c2f6669656c644f66537475646965733e3c6669656c644f66537475646965733e3c6b65793e315f313c2f6b65793e3c76616c75653e3230303c2f76616c75653e3c2f6669656c644f66537475646965733e3c6669656c644f66537475646965733e3c6b65793e3"
}
```

#### Success Response Body Details

Parameter Name | Data Type | Description
-| -|-
credistring|string|calculated credit string in the encoded format


### Error Responses

#### Status 401 (Authentication Failed)
if the authentication header contains invalid details then  you will get error response object as below
```json
{
    "errorCode": "AUTHENTICATION_ERROR",
    "errorMessage": "error message"
}
```
#### Status 403 (Forbidden)    
if the authentication header contains valid details but don't have access to the requested resource then you will get below response object
```json
{
    "errorCode": "AUTHORIZATION_ERROR",
    "errorMessage": "error message"
}
```
#### Status 422 (Unprocessable entity)    
if the input posted to the api is invalid then we will get below error response object. 
- sample invalid input

```json
{
	"creditString": null,
	"updatedCredits": [
		{
			"regulatorId": 190,
			"type": "Live",
			"pType": "",
			"approval": true,
			"categoryCredits": [
				{
					"category": "TX",
					"credit": 1
				},
				{
					"category": "Gen",
					"credit": 9
				}
			],
			"properties": []
		}
	]
}
```

##### error response for invalid input
```json
{
    "errorCode": "INVALID_INPUT",
    "errorMessage": "Validation failed , see the error details for errors",
    "errorDetails": [
        {
            "key": "creditString",
            "error": "creditString is required"
        }
    ]
}
```
