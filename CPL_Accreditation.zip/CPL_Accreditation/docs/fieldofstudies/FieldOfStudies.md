# fieldOfStudies
this api will give the field of studies for the given industries
### URI
    /accreditation/fieldofstudies
### Method
    POST
### Auth Required
    YES
### Resource and Query Parameters
    None
### Header Parameters
#### Supplying basic auth headers
If you need to you may construct and send basic auth headers yourself. To do this you need to perform the following steps:

-   Build a string of the form username:password
-   Base64 encode the string
-   Supply an “Authorization” header with content “Basic ” followed by the encoded string. For        example, the string fred:fred encodes to ZnJlZDpmcmVk in base64, so you would make the           request  using that header
-   username is the organization username 
-   password is the secret key given for the organization

### Request Body
```json
{
	"industries":[1,2]
}
```
#### Industries
-   give the list of industries that you want to get field of studies and questions
-   supported industry id's are **1 and 2**

###  Success Response
-  Status Code: 200
-  Content : 
```
  {
    "distributorDefinitions": [
        {
            "industryId": 1,
            "questions": [
                {
                    "question": "This activity is 1) sponsored by a NASBA Registry provider, and 2) meets NASBA Registry standards for accreditation?",
                    "options": [
                        {
                            "displayName": "No",
                            "key": "false"
                        }
                    ],
                    "questionFieldType": "RADIO",
                    "key": "nasba"
                },
                {
                    "question": "This activity is 1) sponsored by a NASBA QAS provider, and 2) meets NASBA QAS standards for accreditation?",
                    "options": [
                        {
                            "displayName": "No",
                            "key": "false"
                        }
                    ],
                    "questionFieldType": "RADIO",
                    "key": "qas"
                }
            ],
            "contentFields": [
                {
                    "label": "Accounting",
                    "key": "1_0"
                }
            ]
        },
        {
            "industryId": 2,
            "questions": [
                {
                    "question": "Select the option that best describes the sponsor of this activity:",
                    "options": [
                        {
                            "displayName": "In_House Governmental Legal Department",
                            "key": "IHG"
                        }
                    ],
                    "questionFieldType": "RADIO",
                    "key": "provider"
                },
                {
                    "question": "Select the option that best describes the style of this \"technologically_delivered\" activity:",
                    "options": [
                        {
                            "displayName": "Interactive / Verified",
                            "key": "interactive"
                        }
                    ],
                    "questionFieldType": "RADIO",
                    "key": "selfstudystyle"
                }
            ],
            "contentFields": [
                {
                    "label": "General",
                    "key": "2_0"
                }
            ]
        }
    ]
}
```

#### Success Response Body Details

Parameter Name | Data Type | Description
-| -|-
distributorDefinitions | array of objects | array of distributor definition objects based on the industries
distributorDefinitions.industryId  | integer| industry id **1** represents **accountancy** and **2** represents **law**
formatId  | integer | delivery formats available from the delivery formats api
fieldOfStudies| array of field of study objects| field of studies that you want to calculate credit  string
fieldOfStudies.key  |string   | key id's received from the field of studies API
fieldOfStudies.value | string | participation time or teaching time for that field of study in minutes
distributorDefinitions.questions | array of question objects | questions and there related answers
distributorDefinitions.questions.question | string | question that is recieved from field of studies api
distributorDefinitions.questions.questionFieldType | string | supported types are RADIO , TEXT_FIELD ,DATE
distributorDefinitions.questions.key | string | question key 
distributorDefinitions.questions.answer|string|answer for the question 
distributorDefinitions.questions.options | array of option objects | if the question has one or more than one option it will come in this array
distributorDefinitions.questions.options.option.displayName | string| option display name
distributorDefinitions.questions.options.option.key | string | option key which will be used to send the value
distributorDefinitions.contentFields | array of field of study objects | this array contains field of study object display name and key
distributorDefinitions.contentFields.label | string | label for the field of study
distributorDefinitions.contentFields.key| string | key for the field of study

### Error Responses

#### Status 401 (Authentication Failed)
if the authentication header contains invalid details then  you will get error response object as below
```json
{
    "errorCode": "AUTHENTICATION_ERROR",
    "errorMessage": "error message"
}
```
#### Status 403 (Forbidden)    
if the authentication header contains valid details but don't have access to the requested resource then you will get below response object
```json
{
    "errorCode": "AUTHORIZATION_ERROR",
    "errorMessage": "error message"
}
```
#### Status 422 (Unprocessable entity)    
if the input posted to the api is invalid then we will get below error response object. 
- sample invalid input

```json
{
	"industries":null
}
```
##### error response for invalid input
```json
{
    "errorCode": "INVALID_INPUT",
    "errorMessage": "Validation failed , see the error details for errors",
    "errorDetails": [
        {
            "key": "industries",
            "error": "may not be empty"
        },
        {
            "key": "industries",
            "error": "may not be null"
        }
    ]
}
```
