# OrganizationRegulators
this api will give the all the regulators associated with the given organization
### URI
    /accreditation/regulators/{orgUserName}
### Method
    GET
### Auth Required
    YES
### Resource and Query Parameters
- You must include the organization name in the path
- example uri /accreditation/regulators/some_org_name

### Header Parameters
#### Supplying basic auth headers
If you need to you may construct and send basic auth headers yourself. To do this you need to perform the following steps:

-   Build a string of the form username:password
-   Base64 encode the string
-   Supply an “Authorization” header with content “Basic ” followed by the encoded string. For        example, the string fred:fred encodes to ZnJlZDpmcmVk in base64, so you would make the request     using that header
-   username is the organization username 
-   password is the secret key given for the organization

###  Success Response
-  Status Code: 200
-  Content : 
```
  {
    "industries": [
        {
            "industryId": 1,
            "regulators": [
                {
                    "id": 217,
                    "name": "Accredited in Business Valuation (ABV - AICPA)"
                },
                {
                    "id": 92,
                    "name": "AICPA"
                }
            ]
        },
        {
            "industryId": 2,
            "regulators": [
                {
                    "id": 2,
                    "name": "Alabama"
                },
                {
                    "id": 165,
                    "name": "Alaska"
                }
            ]
        }
    ]
}
```

#### Industry
an industry associated with the organization 

##### Properties
-   industryId: 1 (number) - The unique identifier for a Industry 
--  industry id **1** represents **accountancy** and **2** represents **law** 
-   regulators: all the regulators associated with the industry or vertical (array[regulator_objects])
-- **regulator properties**
-- id : 217 (number) - The unique identifier for a Regulator
-- name: Accredited in Business Valuation (ABV - AICPA) (string) - name of the regulator

### Error Responses
#### Status 401 (Authentication Failed)
if the authentication header contains invalid details then  you will get error response object as below

```json
{
    "errorCode": "AUTHENTICATION_ERROR",
    "errorMessage": "error message"
}
```

#### Status 403 (Forbidden)    
if the authentication header contains valid details but don't have access to the requested resource then you will get below response object
```json
{
    "errorCode": "AUTHORIZATION_ERROR",
    "errorMessage": "error message"
}
```
#### Status 422 (Unprocessable entity)   

if the path param **orgUserName** is invalid then we will get below error response object. 
```json
{
    "errorCode": "INVALID_INPUT",
    "errorMessage": "error message"
}
```
