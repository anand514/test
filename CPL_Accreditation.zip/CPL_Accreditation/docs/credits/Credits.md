# Credits
this api will give the calculated credits in detail category objects.
### URI
    /accreditation/credits
### Method
    POST
### Auth Required
    YES
### Resource and Query Parameters
    None
### Header Parameters
#### Supplying basic auth headers
If you need to you may construct and send basic auth headers yourself. To do this you need to perform the following steps:

-   Build a string of the form username:password
-   Base64 encode the string
-   Supply an “Authorization” header with content “Basic ” followed by the encoded string. For        example, the string fred:fred encodes to ZnJlZDpmcmVk in base64, so you would make the           request  using that header
-   username is the organization username 
-   password is the secret key given for the organization

### Request Body
Parameter Name | Data Type | Description
-| -|-
industryId  | integer| industry id **1** represents **accountancy** and **2** represents **law**
formatId  | integer | delivery formats available from the delivery formats api
fieldOfStudies| array of field of study objects| field of studies that you want to calculate credit  string
fieldOfStudies.key  |string   | key id's received from the field of studies API
fieldOfStudies.value | string | participation time or teaching time for that field of study in minutes
questions | array of question objects | questions and there related answers
questions.question | string | question that is recieved from field of studies api
questions.answer|string|answer for the question 
regulators|array of integers | array of regulatorid's for those credit string need to be calculated

#### sample request body
```json
{  
   "input":{
   	
         "industryId":1,
         "formatId":1,
         "fieldOfStudies":[  
            {  
               "key":"1_0",
               "value":"100"
              
            },
            {  
               "key":"1_1",
               "value":"200"
           
            }
         ],
         "questions":[  
            {  
               "question":"nasba",
               "answer":"true"
            }
         ],
         "regulators":[  
           217
         ]

}
}
```

###  Success Response

-  Status Code: 200
-  Sample Success Response Body : 
```
{
    "credits": [
        {
            "approval": true,
            "pType": "",
            "categoryCredits": [
                {
                    "category": "TX",
                    "credit": 1
                }
            ],
            "type": "Live",
            "regulatorId": 190,
            "properties": []
        },
        {
            "approval": true,
            "pType": "",
            "categoryCredits": [
                {
                    "category": "Gen",
                    "credit": 11
                }
            ],
            "type": "Live",
            "regulatorId": 189,
            "properties": []
        }
    ]
}
```

#### Success Response Body Details

Parameter Name | Data Type | Description
-| -|-
credits| array of credit objects | array of credit objects for the individual categories 
credits.regulatorId | integer | regulator id or jurisdiction id 
credits.type  | string | format of the updated credit type 
credits.pType | string | ptype
credits.approval | boolean | approval
credits.categoryCredits | array of credit objects | array of credit objects for which you want to update the credits
credits.categoryCredits.category |string| credit category
credits.categoryCredits.credit | integer | updated credit value
credits.properties | array of properties objects | array of properties 


### Error Responses

#### Status 401 (Authentication Failed)
if the authentication header contains invalid details then  you will get error response object as below
```json
{
    "errorCode": "AUTHENTICATION_ERROR",
    "errorMessage": "error message"
}
```
#### Status 403 (Forbidden)    
if the authentication header contains valid details but don't have access to the requested resource then you will get below response object
```json
{
    "errorCode": "AUTHORIZATION_ERROR",
    "errorMessage": "error message"
}
```
#### Status 422 (Unprocessable entity)    
if the input posted to the api is invalid then we will get below error response object. 
- sample invalid input

```json
{  
   "input":{
   	
         "industryId":1,
         "formatId":1,
         "fieldOfStudies":[  
            {  
               "key":"1_0",
               "value":"100"
              
            },
            {  
               "key":"1_1",
               "value":"200"
           
            },
            {  
                "key":"1_2",
               "value":"50"
            },
            {  
                "key":"1_3",
               "value":"50"
            }
         ],
         "questions":null,
         "regulators":[  
           217
         ]



}
}
```

##### error response for invalid input

```json
{
    "errorCode": "INVALID_INPUT",
    "errorMessage": "Validation failed , see the error details for errors",
    "errorDetails": [
        {
            "key": "input.questions",
            "error": "may not be empty"
        },
        {
            "key": "input.questions",
            "error": "may not be null"
        }
    ]
}
```
