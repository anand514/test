# delivery formats
this api will give the all the delivery formats supported by the application
### URI
    /accreditation/deliveryformats
### Method
    GET
### Auth Required
    YES
### Resource and Query Parameters
    NONE
### Header Parameters
#### Supplying basic auth headers
If you need to you may construct and send basic auth headers yourself. To do this you need to perform the following steps:

-   Build a string of the form username:password
-   Base64 encode the string
-   Supply an “Authorization” header with content “Basic ” followed by the encoded string. For        example, the string fred:fred encodes to ZnJlZDpmcmVk in base64, so you would make the request     using that header
-   username is the organization username 
-   password is the secret key given for the organization

###  Success Response
-  Status Code: 200
-  Content : 

```json
  {
     "formats": [
        {
            "id": 34,
            "name": "Audio (Group)"
        },
        {
            "id": 35,
            "name": "Audiotape"
        }
    ]
}
```
### Error Responses
#### Status 401 (Authentication Failed)
if the authentication header contains invalid details then  you will get error response object as below
```json
{
    "errorCode": "AUTHENTICATION_ERROR",
    "errorMessage": "error message"
}
```
#### Status 403 (Authorization Failed)    
if the authentication header contains valid details but don't have access to the requested resource then you will get below response object
```json
{
    "errorCode": "AUTHORIZATION_ERROR",
    "errorMessage": "error message"
}
```
