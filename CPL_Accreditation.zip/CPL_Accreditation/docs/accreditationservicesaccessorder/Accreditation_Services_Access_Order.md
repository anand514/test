## Accreditation services access order
This documentation will suggest you to order of accessing the accreditation api's , we need to access the api's in order because there some dependencies between the api's.

Below given order is accessing order of the api's
##### Delivery formats API
---
-   Hit the [Delivery Formats API](https://git.sami.int.thomsonreuters.com/tr/cpl-accreditation-webapi/blob/master/deliveryformats/DeliveryFormats.md) to get all the delivery formats supported by the application

##### Regulators
---
-   Hit the [Organization Regulators API](https://git.sami.int.thomsonreuters.com/tr/cpl-accreditation-webapi/blob/master/organizationregulators/OrganizationRegulators.md) to get regulators associated the organization

##### Field of studies and questions assoicated with the industries
---
-   Hit the [Field of studies API](https://git.sami.int.thomsonreuters.com/tr/cpl-accreditation-webapi/blob/master/fieldofstudies/FieldOfStudies.md) to get all the field of studies and questions associated with industries.

##### Credit string (POST)
---
-   Hit the [Credit string API(POST Request)](https://git.sami.int.thomsonreuters.com/tr/cpl-accreditation-webapi/blob/master/creditstring/post/CreditString.md) to get the calculated encoded credit string from the given field of study hours and answer's to the questions  and ceformat id and industry id and regulator id's.
-   This api has a dependency with the below api's
-   Delivery formats API
-   Regulators
-   Field of studies and questions assoicated with the industries

##### Credits
---
-   Hit the [Credits](https://git.sami.int.thomsonreuters.com/tr/cpl-accreditation-webapi/blob/master/credits/Credits.md) to get the calculated credits in detail  from the given field of studies hours and questions and their answer's  and ceformat id and industry id and regulator id's.
-   This api has a dependency with the below api's
-   Delivery formats API
-   Regulators
-   Field of studies and questions assoicated with the industries

##### Credit string (PUT)
---
-   Hit the [Credit string API(PUT Request)](https://git.sami.int.thomsonreuters.com/tr/cpl-accreditation-webapi/blob/master/creditstring/post/CreditString.md) to get the calculated encoded credit string from the old encoded credit string and updated credits.
-   Credit string (POST)
-   Credits

##### Credits from credit string 
---
-   Hit the [Credits from credit string API](https://git.sami.int.thomsonreuters.com/tr/cpl-accreditation-webapi/blob/master/creditsfromcreditstring/CreditsFromCreditString.md)  to get the details credits from encoded  credit string.
-   Credit string (POST) or  Credit string (PUT).

